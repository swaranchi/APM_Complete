CREATE SCHEMA IF NOT EXISTS apm;
SET search_path = apm, public;

CREATE TABLE IF NOT EXISTS users (
  user_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  username VARCHAR(64) NOT NULL UNIQUE,
  email VARCHAR(254),
  auth_hash VARCHAR(255),
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS vault_entries (
  entry_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  owner_user_id BIGINT NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
  target VARCHAR(512),
  encrypted_blob BYTEA NOT NULL,
  enc_algo VARCHAR(32) NOT NULL DEFAULT 'AES-256-CBC',
  enc_iv BYTEA NOT NULL,
  kdf_params JSONB,
  created_at timestamptz NOT NULL DEFAULT now()
);
