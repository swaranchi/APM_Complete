import React, { useEffect } from 'react'
import { useNavigate } from 'react-router-dom'

export default function App(){
  const nav = useNavigate()
  useEffect(()=>{
    if(localStorage.getItem('apm_token')) nav('/app/pm/vaults')
    else nav('/login')
  },[])
  return <div/>
}
