import React from 'react'
import { createRoot } from 'react-dom/client'
import { createBrowserRouter, RouterProvider } from 'react-router-dom'
import App from './App.jsx'
import Login from './pages/Login.jsx'
import Register from './pages/Register.jsx'
import Forgot from './pages/Forgot.jsx'
import Reset from './pages/Reset.jsx'
import Dashboard from './layouts/Dashboard.jsx'
import PAMAccounts from './pages/pam/Accounts.jsx'
import PAMPolicies from './pages/pam/Policies.jsx'
import PAMMyReq from './pages/pam/MyRequests.jsx'
import PAMIncoming from './pages/pam/IncomingRequests.jsx'
import Vault from './pages/pm/Vault.jsx'
import Settings from './pages/pm/Settings.jsx'

const router = createBrowserRouter([
  { path: '/', element: <App/> },
  { path: '/login', element: <Login/> },
  { path: '/register', element: <Register/> },
  { path: '/forgot', element: <Forgot/> },
  { path: '/reset', element: <Reset/> },
  { path: '/app', element: <Dashboard/>,
    children: [
      { path: 'pam/accounts', element: <PAMAccounts/> },
      { path: 'pam/policies', element: <PAMPolicies/> },
      { path: 'pam/my-requests', element: <PAMMyReq/> },
      { path: 'pam/incoming-requests', element: <PAMIncoming/> },
      { path: 'pm/vaults', element: <Vault/> },
      { path: 'pm/settings', element: <Settings/> }
    ]
  }
])

createRoot(document.getElementById('root')).render(<RouterProvider router={router} />)
