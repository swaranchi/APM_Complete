import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { api } from '../api'
import Toast from '../Toast.jsx'

export default function Login(){
  const nav = useNavigate()
  const [username,setUsername]=useState('')
  const [password,setPassword]=useState('')
  const [err,setErr]=useState(null)
  const [ok,setOk]=useState(null)

  async function submit(e){
    e.preventDefault()
    setErr(null); setOk(null)
    try{
      const { token, message } = await api('/auth/login',{ method:'POST', body: JSON.stringify({ username, password })})
      localStorage.setItem('apm_token', token)
      sessionStorage.setItem('apm_master', password)
      setOk(message || 'Logged in successfully.')
      setTimeout(()=>nav('/app/pm/vaults'), 600)
    }catch(e){ setErr(e.message) }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-700 to-blue-900 flex items-center justify-center p-4">
      <Toast msg={err} type="error" onClose={()=>setErr(null)} />
      <Toast msg={ok} type="success" onClose={()=>setOk(null)} />
      <div className="w-full max-w-md">
        <div className="flex flex-col items-center mb-6">
          <div className="w-20 h-20 rounded-2xl bg-white/10 backdrop-blur flex items-center justify-center shadow-lg">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" className="w-12 h-12 text-white" fill="none" stroke="currentColor" strokeWidth="1.6">
              <rect x="6" y="8" width="52" height="40" rx="6" className="stroke-white" />
              <circle cx="32" cy="28" r="7" className="stroke-white" />
              <path d="M32 21v3M32 35v3" className="stroke-white" strokeLinecap="round"/>
            </svg>
          </div>
          <h1 className="mt-4 text-2xl font-extrabold text-white drop-shadow">Advanced Password Manager</h1>
          <p className="text-blue-200 mt-1">Secure login with your master password</p>
        </div>

        <div className="bg-white rounded-2xl shadow-2xl p-6">
          <form className="space-y-4" onSubmit={submit}>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Username</label>
              <input className="w-full border rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-300"
                     placeholder="your_username" value={username} onChange={e=>setUsername(e.target.value)} />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Master password</label>
              <input type="password" className="w-full border rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-300"
                     placeholder="••••••••" value={password} onChange={e=>setPassword(e.target.value)} />
            </div>

            <div className="flex items-center justify-between text-sm">
              <label className="inline-flex items-center gap-2">
                <input type="checkbox" className="rounded border-gray-300" />
                <span className="text-gray-600">Remember username</span>
              </label>
              <Link className="text-blue-600 hover:underline" to="/forgot">Forgot password?</Link>
            </div>

            <button className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 rounded-xl transition shadow">
              Continue
            </button>
          </form>
        </div>

        <p className="text-center mt-6 text-sm text-blue-100">
          New to APM? <Link to="/register" className="text-white font-semibold underline">Create account</Link>
        </p>
      </div>
    </div>
  )
}
