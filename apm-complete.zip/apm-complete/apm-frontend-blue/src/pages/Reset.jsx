import React, { useState, useEffect } from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom'
import { api } from '../api'
import Toast from '../Toast.jsx'

export default function Reset(){
  const nav = useNavigate()
  const [sp]=useSearchParams()
  const [token,setToken]=useState('')
  const [newPassword,setP]=useState('')
  const [err,setErr]=useState(null); const [ok,setOk]=useState(null)

  useEffect(()=>{ const t=sp.get('token'); if(t) setToken(t) },[])

  async function submit(e){
    e.preventDefault()
    setErr(null); setOk(null)
    try{
      const r = await api('/auth/reset',{ method:'POST', body: JSON.stringify({ token, newPassword })})
      setOk(r.message || 'Password reset.')
      setTimeout(()=>nav('/login'), 1000)
    }catch(e){ setErr(e.message) }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-700 to-blue-900 flex items-center justify-center p-4">
      <Toast msg={err} type="error" onClose={()=>setErr(null)} />
      <Toast msg={ok} type="success" onClose={()=>setOk(null)} />
      <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl p-6">
        <h1 className="text-2xl font-extrabold text-gray-900 mb-4">Reset password</h1>
        <form className="space-y-4" onSubmit={submit}>
          <input className="w-full border rounded-lg px-4 py-3" placeholder="Reset token" value={token} onChange={e=>setToken(e.target.value)} />
          <input type="password" className="w-full border rounded-lg px-4 py-3" placeholder="New master password" value={newPassword} onChange={e=>setP(e.target.value)} />
          <button className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 rounded-xl">Set new password</button>
        </form>
      </div>
    </div>
  )
}
