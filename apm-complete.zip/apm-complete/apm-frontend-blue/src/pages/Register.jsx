import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { api } from '../api'
import Toast from '../Toast.jsx'

export default function Register(){
  const nav = useNavigate()
  const [username,setUsername]=useState('')
  const [email,setEmail]=useState('')
  const [displayName,setDisplay]=useState('')
  const [password,setPassword]=useState('')
  const [err,setErr]=useState(null)
  const [ok,setOk]=useState(null)

  async function submit(e){
    e.preventDefault()
    setErr(null); setOk(null)
    try{
      const { message } = await api('/auth/register',{
        method:'POST',
        body: JSON.stringify({ username,email,displayName,password })
      })
      setOk(message || 'Account created successfully.')
      setTimeout(()=>nav('/login'), 800)
    }catch(e){ setErr(e.message) }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-700 to-blue-900 flex items-center justify-center p-4">
      <Toast msg={err} type="error" onClose={()=>setErr(null)} />
      <Toast msg={ok} type="success" onClose={()=>setOk(null)} />
      <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl p-6">
        <h1 className="text-2xl font-extrabold text-gray-900 mb-4">Create Account</h1>
        <form className="space-y-4" onSubmit={submit}>
          <input className="w-full border rounded-lg px-4 py-3" placeholder="Username" value={username} onChange={e=>setUsername(e.target.value)} />
          <input className="w-full border rounded-lg px-4 py-3" placeholder="Email (optional)" value={email} onChange={e=>setEmail(e.target.value)} />
          <input className="w-full border rounded-lg px-4 py-3" placeholder="Display name (optional)" value={displayName} onChange={e=>setDisplay(e.target.value)} />
          <input type="password" className="w-full border rounded-lg px-4 py-3" placeholder="Master password" value={password} onChange={e=>setPassword(e.target.value)} />
          <button className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 rounded-xl">Create account</button>
        </form>
      </div>
    </div>
  )
}
