import React, { useState } from 'react'

const sections = ['My account','Security','Emergency Access']

export default function Settings(){
  const [section,setSection]=useState('My account')
  return (
    <div className="space-y-4">
      <h2 className="text-xl font-bold text-gray-900">Settings</h2>
      <div className="flex gap-2">
        {sections.map(s=>(
          <button key={s} onClick={()=>setSection(s)} className={`px-3 py-2 rounded-lg text-sm border ${section===s?'bg-blue-600 text-white border-blue-600':'bg-white text-gray-700'}`}>{s}</button>
        ))}
      </div>

      <div className="bg-gray-50 border rounded-xl p-4 text-gray-700">
        <div className="font-semibold mb-2">{section}</div>
        <p>Placeholder content for <b>{section}</b>. We will wire this next.</p>
      </div>
    </div>
  )
}
