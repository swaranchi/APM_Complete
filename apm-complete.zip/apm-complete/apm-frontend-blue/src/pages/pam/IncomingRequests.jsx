// src/pages/pam/IncomingRequests.jsx
import React from 'react'
export default function PAMIncomingRequests(){
  return <div className='space-y-2'>
    <h2 className='text-xl font-bold text-gray-900'>Incoming Requests</h2>
    <p className='text-gray-600'>Approve/deny incoming requests.</p>
  </div>
}
