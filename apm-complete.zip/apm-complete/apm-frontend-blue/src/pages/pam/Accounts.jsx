import React, { useEffect, useState } from 'react';
import { api } from '../../api';

export default function PAMAccounts() {
  const [items, setItems] = useState([]);

  async function load() {
    const r = await api('/pam/accounts');
    setItems(r.items || []);
  }
  useEffect(() => { load(); }, []);

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-bold text-gray-900">Accounts</h2>
      <p className="text-gray-600">Manage privileged accounts and targets.</p>

      <div className="border rounded-xl overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-gray-50 text-gray-600">
            <tr>
              <th className="text-left p-3">Name</th>
              <th className="text-left p-3">Host</th>
              <th className="text-left p-3">Type</th>
              <th className="text-left p-3">Username</th>
              <th className="text-left p-3">Created</th>
            </tr>
          </thead>
          <tbody>
            {items.map(a => (
              <tr key={a.account_id} className="border-t">
                <td className="p-3">{a.name}</td>
                <td className="p-3">{a.host ?? '—'}{a.port ? `:${a.port}` : ''}</td>
                <td className="p-3">{a.account_type}</td>
                <td className="p-3">{a.username ?? '—'}</td>
                <td className="p-3">{new Date(a.created_at).toLocaleString()}</td>
              </tr>
            ))}
            {!items.length && (
              <tr><td className="p-6 text-center text-gray-500" colSpan="5">No accounts yet.</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
