import React, { useEffect, useState } from 'react';
import { api } from '../../api';

export default function PAMPolicies() {
  const [items, setItems] = useState([]);
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');

  async function load() {
    const r = await api('/pam/policies');
    setItems(r.items || []);
  }
  useEffect(() => { load(); }, []);

  async function create(e) {
    e.preventDefault();
    await api('/pam/policies', {
      method: 'POST',
      body: JSON.stringify({ name, description, rules: {} })
    });
    setName(''); setDescription('');
    await load();
  }

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-bold text-gray-900">Policies</h2>
      <p className="text-gray-600">Define approval/access policies.</p>

      <form onSubmit={create} className="flex gap-2 items-end">
        <div>
          <label className="block text-xs text-gray-600 mb-1">Name</label>
          <input className="border rounded px-3 py-2" value={name} onChange={e=>setName(e.target.value)} placeholder="Policy name" />
        </div>
        <div className="flex-1">
          <label className="block text-xs text-gray-600 mb-1">Description</label>
          <input className="border rounded px-3 py-2 w-full" value={description} onChange={e=>setDescription(e.target.value)} placeholder="Optional description" />
        </div>
        <button className="px-3 py-2 rounded bg-blue-600 text-white">Add</button>
      </form>

      <div className="border rounded-xl overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-gray-50 text-gray-600">
            <tr>
              <th className="text-left p-3">Name</th>
              <th className="text-left p-3">Description</th>
              <th className="text-left p-3">Created</th>
            </tr>
          </thead>
          <tbody>
            {items.map(p => (
              <tr key={p.policy_id} className="border-t">
                <td className="p-3">{p.name}</td>
                <td className="p-3">{p.description ?? '—'}</td>
                <td className="p-3">{new Date(p.created_at).toLocaleString()}</td>
              </tr>
            ))}
            {!items.length && (
              <tr><td className="p-6 text-center text-gray-500" colSpan="3">No policies yet.</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
