// src/pages/pam/MyRequests.jsx
import React from 'react'
export default function PAMMyRequests(){
  return <div className='space-y-2'>
    <h2 className='text-xl font-bold text-gray-900'>My Requests</h2>
    <p className='text-gray-600'>Track your access requests.</p>
  </div>
}
