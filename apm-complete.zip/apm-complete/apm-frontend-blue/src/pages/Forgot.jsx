import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { api } from '../api'
import Toast from '../Toast.jsx'

export default function Forgot(){
  const nav = useNavigate()
  const [usernameOrEmail,setV]=useState('')
  const [err,setErr]=useState(null); const [ok,setOk]=useState(null)

  async function submit(e){
    e.preventDefault()
    setErr(null); setOk(null)
    try{
      const r = await api('/auth/forgot',{ method:'POST', body: JSON.stringify({ usernameOrEmail })})
      setOk(r.message + (r.token ? ' (DEV token: '+ r.token +')' : ''))
      if(r.token){ setTimeout(()=>nav('/reset?token='+encodeURIComponent(r.token)), 1200) }
    }catch(e){ setErr(e.message) }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-700 to-blue-900 flex items-center justify-center p-4">
      <Toast msg={err} type="error" onClose={()=>setErr(null)} />
      <Toast msg={ok} type="success" onClose={()=>setOk(null)} />
      <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl p-6">
        <h1 className="text-2xl font-extrabold text-gray-900 mb-4">Forgot password</h1>
        <form className="space-y-4" onSubmit={submit}>
          <input className="w-full border rounded-lg px-4 py-3" placeholder="Username or Email" value={usernameOrEmail} onChange={e=>setV(e.target.value)} />
          <button className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 rounded-xl">Generate reset link</button>
        </form>
      </div>
    </div>
  )
}
