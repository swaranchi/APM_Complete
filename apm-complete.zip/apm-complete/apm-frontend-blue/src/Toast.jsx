// src/Toast.jsx
import React, { useEffect, useState } from 'react'
import './toast.css'
export default function Toast({ msg, type='info', duration=2200, onClose }) {
  const [show,setShow]=useState(Boolean(msg))
  useEffect(()=>{
    if(!msg) return;
    setShow(true);
    const t=setTimeout(()=>{ setShow(false); onClose?.() }, duration);
    return ()=>clearTimeout(t);
  },[msg,duration,onClose]);
  if(!show) return null;
  return <div className={`toast ${type==='error'?'error':type==='success'?'success':''}`}>{msg}</div>
}
