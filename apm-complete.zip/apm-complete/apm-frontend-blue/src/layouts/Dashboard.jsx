import React from 'react'
import { NavLink, Outlet, useNavigate } from 'react-router-dom'

function Item({ to, children }){
  return (
    <NavLink to={to} className={({isActive})=>
      'block px-3 py-2 rounded-lg text-sm ' + (isActive ? 'bg-white/20 text-white' : 'text-blue-100 hover:bg-white/10')
    }>
      {children}
    </NavLink>
  )
}

export default function Dashboard(){
  const nav = useNavigate()
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-700 to-blue-900 text-white">
      <div className="flex">
        <aside className="w-72 p-4 space-y-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" className="w-7 h-7" fill="none" stroke="currentColor" strokeWidth="1.6">
                <rect x="6" y="8" width="52" height="40" rx="6" className="stroke-white" />
                <circle cx="32" cy="28" r="7" className="stroke-white" />
              </svg>
            </div>
            <div>
              <div className="font-bold leading-tight">APM Console</div>
              <div className="text-xs text-blue-100">Secure by design</div>
            </div>
          </div>

          <div>
            <div className="text-xs uppercase tracking-wider text-blue-200 mb-2">APM Privileged Access Security</div>
            <div className="space-y-1">
              <Item to="/app/pam/accounts">Accounts</Item>
              <Item to="/app/pam/policies">Policies</Item>
              <Item to="/app/pam/my-requests">My Requests</Item>
              <Item to="/app/pam/incoming-requests">Incoming Requests</Item>
            </div>
          </div>

          <div>
            <div className="text-xs uppercase tracking-wider text-blue-200 mb-2">APM Password Manager</div>
            <div className="space-y-1">
              <Item to="/app/pm/vaults">Vaults</Item>
              <Item to="/app/pm/settings">Settings</Item>
            </div>
          </div>

          <button
            onClick={()=>{ localStorage.removeItem('apm_token'); sessionStorage.removeItem('apm_master'); nav('/login'); }}
            className="mt-6 w-full bg-white/10 hover:bg-white/20 transition rounded-lg py-2 text-sm"
          >
            Logout
          </button>
        </aside>

        <main className="flex-1 bg-white rounded-l-3xl shadow-2xl p-6 min-h-screen">
          <Outlet />
        </main>
      </div>
    </div>
  )
}
