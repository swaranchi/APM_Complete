const BASE = import.meta.env.VITE_API_URL ?? 'http://localhost:4000';

export function authHeader() {
  const t = localStorage.getItem('apm_token');
  return t ? { Authorization: `Bearer ${t}` } : {};
}

export async function api(path, init) {
  const res = await fetch(`${BASE}${path}`, {
    ...init,
    headers: { 'Content-Type': 'application/json', ...authHeader(), ...(init?.headers||{}) }
  });
  if (!res.ok) {
    let msg = 'Request failed';
    try { msg = (await res.json()).error || msg; } catch {}
    throw new Error(msg);
  }
  return res.json();
}
