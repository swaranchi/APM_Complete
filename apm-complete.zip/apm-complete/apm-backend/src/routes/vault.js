import { Router } from 'express';
import { authGuard } from '../auth.js';
import { query } from '../db.js';
const r = Router();
r.use(authGuard);

r.get('/', async(req,res)=>{
  const uid = req.user.uid;
  const {rows} = await query(`SELECT entry_id,name,target,created_at FROM apm.vault_entries WHERE owner_user_id=$1 ORDER BY created_at DESC`,[uid]);
  res.json({items:rows});
});

r.post('/', async(req,res)=>{
  const uid = req.user.uid;
  const {name,target,encrypted_blob,enc_iv,kdf_params} = req.body ?? {};
  if(!name || !encrypted_blob || !enc_iv) return res.status(400).json({error:"missing required"});
  const {rows} = await query(
    `INSERT INTO apm.vault_entries(name,owner_user_id,target,encrypted_blob,enc_iv,kdf_params)
     VALUES($1,$2,$3,decode($4,'base64'),decode($5,'base64'),$6::jsonb)
     RETURNING entry_id,name,target,created_at`,
    [name,uid,target??null,encrypted_blob,enc_iv,JSON.stringify(kdf_params??{})]
  );
  res.json(rows[0]);
});

export default r;
