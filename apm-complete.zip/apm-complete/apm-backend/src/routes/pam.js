import { Router } from 'express';
import { query } from '../db.js';
import { authGuard } from '../auth.js';  // <-- named import (fix)

const r = Router();
r.use(authGuard);

/** GET /pam/accounts — list privileged accounts */
r.get('/accounts', async (_req, res) => {
  const { rows } = await query(
    `SELECT account_id, name, host, port, account_type, username, created_at
       FROM apm.pam_accounts
      ORDER BY created_at DESC`
  );
  res.json({ items: rows });
});

/** GET /pam/policies — list policies */
r.get('/policies', async (_req, res) => {
  const { rows } = await query(
    `SELECT policy_id, name, description, rules, created_at
       FROM apm.pam_policies
      ORDER BY created_at DESC`
  );
  res.json({ items: rows });
});

/** POST /pam/policies — create a policy */
r.post('/policies', async (req, res) => {
  const uid = req.user?.uid ?? null;
  const { name, description, rules } = req.body ?? {};
  if (!name) return res.status(400).json({ error: 'name required' });

  const { rows } = await query(
    `INSERT INTO apm.pam_policies (name, description, rules, created_by)
     VALUES ($1,$2,$3::jsonb,$4)
     RETURNING policy_id, name, description, rules, created_at`,
    [name, description ?? null, JSON.stringify(rules ?? {}), uid]
  );
  res.json({ item: rows[0], message: 'Policy created' });
});

export default r;
