import { Router } from 'express';
import argon2 from 'argon2';
import crypto from 'crypto';
import { pool } from '../db.js';
import jwt from 'jsonwebtoken';

const router = Router();
const JWT_SECRET = process.env.JWT_SECRET || "apm_secret_replace_later";

// REGISTER
router.post('/register', async (req, res) => {
  const { username, email, displayName, password } = req.body ?? {};
  if (!username || !password)
    return res.status(400).json({ error: 'username & password required' });

  try {
    const hash = await argon2.hash(password, { type: argon2.argon2id });
    const result = await pool.query(
      `INSERT INTO apm.users (username,email,display_name,auth_hash,is_active)
       VALUES ($1,$2,$3,$4,TRUE)
       RETURNING user_id,username,email,display_name,created_at`,
      [username, email ?? null, displayName ?? null, hash]
    );
    return res.json({ ok: true, message: "Account created successfully.", user: result.rows[0] });
  } catch (err) {
    if (err.code === '23505')
      return res.status(409).json({ error: 'Username or email already exists' });

    return res.status(500).json({ error: 'Database error' });
  }
});

// LOGIN
router.post('/login', async (req, res) => {
  const { username, password } = req.body ?? {};
  if (!username || !password)
    return res.status(400).json({ error: 'username & password required' });

  const result = await pool.query(`SELECT user_id,username,auth_hash,is_active FROM apm.users WHERE username=$1`, [username]);
  const user = result.rows[0];

  if (!user || !user.is_active)
    return res.status(401).json({ error: 'Invalid credentials' });

  const ok = await argon2.verify(user.auth_hash, password);
  if (!ok)
    return res.status(401).json({ error: 'Invalid credentials' });

  const token = jwt.sign({ uid: user.user_id, username: user.username }, JWT_SECRET, { expiresIn: '10h' });

  return res.json({ ok: true, message: "Logged in successfully.", token });
});

// FORGOT PASSWORD (dev mode token return)
router.post('/forgot', async (req, res) => {
  const { usernameOrEmail } = req.body ?? {};
  if (!usernameOrEmail)
    return res.status(400).json({ error: 'usernameOrEmail required' });

  const result = await pool.query(
    `SELECT user_id FROM apm.users WHERE username=$1 OR lower(email)=lower($1)`,
    [usernameOrEmail]
  );

  const user = result.rows[0];

  // Always respond OK (do not reveal user existence)
  if (!user)
    return res.json({ ok: true, message: "If account exists, reset link generated." });

  const token = crypto.randomBytes(24).toString('hex');
  const expiresAt = new Date(Date.now() + 30 * 60 * 1000);

  await pool.query(
    `INSERT INTO apm.password_reset_tokens (token,user_id,expires_at)
     VALUES ($1,$2,$3)`,
    [token, user.user_id, expiresAt]
  );

  // In production → EMAIL IT. For now → return token for testing.
  return res.json({ ok: true, message: "Reset link generated.", token });
});

// RESET PASSWORD
router.post('/reset', async (req, res) => {
  const { token, newPassword } = req.body ?? {};
  if (!token || !newPassword)
    return res.status(400).json({ error: 'token & newPassword required' });

  const t = await pool.query(`SELECT user_id,expires_at,used_at FROM apm.password_reset_tokens WHERE token=$1`, [token]);
  const row = t.rows[0];
  if (!row) return res.status(400).json({ error: 'Invalid token' });
  if (row.used_at) return res.status(400).json({ error: 'Token already used' });
  if (new Date(row.expires_at).getTime() < Date.now())
    return res.status(400).json({ error: 'Token expired' });

  const hash = await argon2.hash(newPassword, { type: argon2.argon2id });

  await pool.query(`UPDATE apm.users SET auth_hash=$1 WHERE user_id=$2`, [hash, row.user_id]);
  await pool.query(`UPDATE apm.password_reset_tokens SET used_at=now() WHERE token=$1`, [token]);

  return res.json({ ok: true, message: "Password reset successful. Please log in." });
});

export default router;
