import jwt from 'jsonwebtoken';
export function signToken(payload) {
  return jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: '12h' });
}
export function authGuard(req, res, next) {
  const header = req.headers.authorization;
  if(!header || !header.startsWith("Bearer ")) return res.status(401).json({error:"Missing token"});
  try {
    req.user = jwt.verify(header.slice(7), process.env.JWT_SECRET);
    next();
  } catch {
    res.status(401).json({error:"Invalid token"});
  }
}
