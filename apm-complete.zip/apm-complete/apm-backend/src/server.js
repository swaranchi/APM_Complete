import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import dotenv from 'dotenv';
import authRoutes from './routes/auth.js';
import vaultRoutes from './routes/vault.js';
import pamRoutes from './routes/pam.js';   // <-- add this

dotenv.config();
const app = express();

app.use(helmet());
app.use(cors());
app.use(express.json());

app.get('/health', (_req, res) => res.json({ ok: true }));

// Route mounts
app.use('/auth', authRoutes);
app.use('/vault', vaultRoutes);
app.use('/pam', pamRoutes);                // <-- mount PAM

const port = process.env.PORT || 4000;
app.listen(port, () => console.log('Backend on', port));
